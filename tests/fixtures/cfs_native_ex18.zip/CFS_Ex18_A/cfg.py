# CFS_Ex18 part A -- fabrication shop: cold-formed steel special bolted moment frames (AISI S400 E4), 50 ft span, 29 frames at 7 ft 1-3/4 in.
import json, os
NAME = "CFS_Ex18_A"
N_FRAMES = 29
COL, RAF = "HSS12X12X1/2", "2x1600S350-118"
BRACED = [1, 10, 19, 28]


def cfg_for(col=COL, raf=RAF):
    return dict(
        arch="CFS_Ex18 fabrication shop on cold-formed steel special bolted moment frames, with a structurally separate two-level mezzanine inside (part B)", occupancy="Fabrication shop (F-1)",
        structure_kind="portal", analysis_fidelity=1, direct_analysis=True, monoslope=True, drift_tolerant_finishes=True,
        span_ft=50.0, eave_ft=24.0, apex_ft=24.0 + 50.0 * 0.25 / 12.0, spacing_ft=200.0 / 28.0, length_ft=200.0, purlin_spacing_ft=5.0, girt_spacing_ft=6.0, site_class="D",
        col_section=col, raf_section=raf, base="pinned",
        D_roof=5.0, collateral=2.0, Lr=20.0, snow_pg=25.0, snow_ce=1.0, snow_ct=1.0, snow_is=1.0, risk_cat="II",
        wind=dict(V=110.0, exposure="C", enclosure="enclosed", Kd=0.85, Kzt=1.0, Ke=1.0, length_ft=200.0, frame_dist_ft=100.0),
        seis=dict(SDS=0.75, SD1=0.30, S1=0.20, R=3.5, Cd=3.5, Om0=3.0, Ie=1.0, W_frame_kip=None, T_drift=None),
        clad=3.0, rho=1.0, system="sbmf",
        sbmf=dict(bolt_pattern=4, N=2, bolt_dia_in=1.0, n_bolts=8, column_splices=False, beam_grade55=True, Fy_beam=55.0, Fy_col=50.0),
        longitudinal_bracing=dict(side_bays={"L": BRACED, "R": BRACED}, roof_bays=BRACED))


SEL = dict(
    Fy=55.0, n_frames=N_FRAMES, Fu_col=62.0,
    col=dict(bracing="closed section: no lateral-torsional or torsional buckling; flexural buckling length = column height in the plane of the frame (K = 1 with the second-order direct analysis) and the girt spacing out of plane, where the girts and the eave strut hold the column"),
    raf=dict(Lb_outside_ft=5.0, Lb_inside_ft=5.0, bracing="top flange of each channel fastened to every purlin (5 ft); bottom flange of each channel braced by a flange brace to every purlin (5 ft), so the unbraced length is 5 ft for either sign of moment"),
    base=dict(anchor_d=0.75, n_anchors=4, grade="F1554 Grade 55", Fu=75.0, plate_t=0.75, plate_in=[14.0, 22.0], weld_leg_in=0.25, embed_in=12.0),
    purlin=dict(continuous=True), girt=dict(continuous=True),
    strap=dict(wall_bays_per_side=4, roof_bays=4, roof_panels=4),
    sway_ratio=60.0, apex_ratio=180.0, extra_seismic_weight_kip=8.0,
    physical_materials=dict(frame="SS55", beam="SS55", hss="A500C", strap="STRAP-50", plate="A572-50", bolt="A325", anchor="F1554-55", screw="C1513", weld="E70"),
    occupancy="Fabrication shop (F-1)",
    materials=[
        dict(item="Moment frame beams, purlins, girts and flange braces", spec="ASTM A653 SS Grade 55, G90", strength="Fy = 55 ksi, Fu = 70 ksi", used="two lipped channels per frame; secondary framing", ids=["SS55"]),
        dict(item="Moment frame columns", spec="ASTM A500 Grade C cold-formed hollow structural sections", strength="Fy = 50 ksi, Fu = 62 ksi", used="one column each side of every frame", ids=["A500C"]),
        dict(item="Bracing straps", spec="ASTM A1008 SS Grade 50, G90 equivalent coating", strength="Fy = 50 ksi, Fu = 65 ksi; Ry = 1.1, Rt = 1.1", used="wall and roof X-bracing", ids=["STRAP-50"]),
        dict(item="Base plates", spec="ASTM A572 Grade 50", strength="Fy = 50 ksi, Fu = 65 ksi", used="column bases", ids=["A572-50"]),
        dict(item="Bolts", spec="ASTM F3125 Grade A325, 1 in. diameter, snug-tight, standard holes", strength="Fnv = 54 ksi (threads in the shear plane)", used="beam-to-column connections; smaller A325 bolts at purlin and girt cleats", ids=["A325"]),
        dict(item="Anchor rods", spec="ASTM F1554 Grade 55", strength="Fy = 55 ksi, Fu = 75 ksi", used="column bases", ids=["F1554-55"]),
        dict(item="Welds", spec="AWS D1.1, E70 electrodes", strength="FEXX = 70 ksi", used="column to base plate", ids=["E70"]),
        dict(item="Screws", spec="ASTM C1513 self-drilling tapping screws, No. 12 (No. 5 drill point where driven into the column wall)", strength="Pss = 2.00 kip (assumed specification minimum; confirm against the product evaluation report)", used="strap ends, panel fastening", ids=["C1513"]),
        dict(item="Roof and wall panel", spec="26 gauge through-fastened metal panel", strength="not relied on as a diaphragm", used="cladding", ids=["PANEL-26"]),
    ],
    edition_statement="AISI S400-20 (Section E4, cold-formed steel special bolted moment frames), AISI S100-16 (2020) with Supplement 2, AISI S240-20 and ASCE/SEI 7-22; hollow columns, base plates, bolts in shear and anchor rods to AISC 360-22.",
    design_notes=[
        "Seismic design category and system: the brief states Seismic Design Category C with frames 'not specifically detailed' (R = 3). With SDS = 0.75 and SD1 = 0.30 in Risk Category II, ASCE 7-22 Tables 11.6-1 and 11.6-2 give Seismic Design Category D, where steel systems not specifically detailed for seismic resistance are not permitted (Table 12.2-1). The transverse frames are therefore cold-formed steel special bolted moment frames to AISI S400 E4 (R = 3.5, Cd = 3.5, Omega0 = 3; one story, 35 ft limit, Table 12.2-1 line C.12).",
        "Frame arrangement (deviation from the brief): nine built-up channel portals at 25 ft cannot be used. The special bolted moment frame is limited by AISI S400 E4.4 to hollow columns up to 12 in. and lipped channel beams up to 20 in. deep, and the 24 ft story is governed by drift. With the largest catalogue members (HSS12x12x1/2 columns, two 1600S350-118 beams) the design story drift is within 0.025 hsx only when the frames are at 8 ft 4 in. or closer, and the 50 ft beam carries its gravity moment (dead load with the 20 psf roof live or minimum snow load) only when the frames are at about 7 ft, so 29 frames at 7 ft 1-3/4 in. are used. The roof slopes 1/4 in 12 one way; the beam is one straight piece.",
        "Mezzanine: the two-level office and storage mezzanine in the last 50 ft of the shop is a structurally separate building (part B of this package) with its own strap-braced walls on all four sides and a seismic joint all round, sized from the design displacements of the two structures (ASCE 7-22 12.12.2). Nothing of the mezzanine is attached to the moment frames, so the frames carry no mezzanine mass and the least-R rule of ASCE 7-22 12.2.3.3 does not arise. The interface record in part B gives the joint width.",
        "Capacity design (AISI S400 E4.3): the beams and columns are checked for the expected moment of the bolted connection, Ve h, with Ve = VS + VB from the slip and bearing of the eight-bolt group at the design story drift; the seismic load effect with overstrength need not exceed Omega0 Eh.",
        "Stability: second-order analysis by the direct analysis method of AISI S100 C1.1 (0.90 tau_b stiffness reduction, notional loads, P-Delta to convergence), so member strengths use K = 1 in the plane of the frame. The stability coefficient of ASCE 7-22 12.8.7 is reported with the drift.",
        "Longitudinal system: tension-only flat-strap X-bracing in four bays of each side wall and of the roof plane, proportioned for the seismic force with the frame value R = 3.5 (not more than the R = 4 of strap-braced walls) and detailed to AISI S400 E3: the strap end connections develop the expected yield strength of the strap, Ry Fy Ag. The through-fastened panels are not credited as diaphragms.",
        "Snow: pg = 25 psf gives a flat-roof snow load of 17.5 psf (20 psf minimum for low slopes); the roof live load of 20 psf is not reduced.",
        "Serviceability: eave sway under D + 0.42W (10-year wind) is held to H/60 and the beam deflection under D + Lr to span/180; the cladding, doors and services crossing the frames are detailed for the design story drift.",
        "Foundations and concrete anchorage are designed by others for the base reactions tabulated; the anchor rods are checked for the seismic load effect with overstrength.",
    ],
)
cfg = cfg_for()
