# CFS_Ex18 part B -- two-level office and storage mezzanine inside the fabrication shop: strap-braced stud walls on all four sides, structurally separate from the moment frames (seismic joint all round)
import sys, math, json, os
sys.path.insert(0, "/home/claude/steltic_env")
from cfsd import bldg

N = 2
H = [10.0, 10.0]
BX, BY = 46.5, 48.0
XW = [0.0, 11.625, 23.25, 34.875, 46.5]         # bearing walls (running north-south); joists span 11 ft 7-1/2 in. between them
D_FLOOR, L_STORE, D_LID, L_LID = 32.0, 125.0, 12.0, 20.0
BAYS_X = [(4.0, 12.0), (30.5, 12.0)]
BAYS_Y = [(4.0, 12.0), (32.0, 12.0)]
lines = [dict(d="X", name="S", pos=0.0, bays=BAYS_X, L=12.0, pieces=[(0.0, BX)], group="stud-end"),
         dict(d="X", name="N", pos=BY, bays=BAYS_X, L=12.0, pieces=[(0.0, BX)], group="stud-end"),
         dict(d="Y", name="W", pos=0.0, bays=BAYS_Y, L=12.0, pieces=[(0.0, BY)], group="stud-side"),
         dict(d="Y", name="E", pos=BX, bays=BAYS_Y, L=12.0, pieces=[(0.0, BY)], group="stud-side")]
gravity = [dict(d="Y", name="B%d" % i, pos=XW[i], a=0.0, b=BY, group="stud-bearing") for i in (1, 2, 3)]
SUP = ["Y:W", "Y:B1", "Y:B2", "Y:B3", "Y:E"]


def zones(level, roof):
    return [dict(id="Z%d" % (i + 1), x_ft=[XW[i], XW[i + 1]], y_ft=[0.0, BY], span="X", supports=[SUP[i], SUP[i + 1]], joist="joist-lid" if roof else "joist-store") for i in range(4)]


rows, pm = bldg.std_materials("strap", "wsp")
PART_A = "/home/claude/steltic_env/jobs/CFS_Ex18_A/design/calc_package_cfs.json"
GAP_SIDE, GAP_END = 12.0, 12.0                  # clear gaps provided, in.: mezzanine wall face to the moment frame columns / to the end-wall framing


def seismic_joint(pkg, wd):
    a = json.load(open(PART_A))
    dA = float(a["seismic"]["Delta_in"]); hA = 24.0 * 12.0
    rows_ = []
    z = 0.0
    dm = 0.0
    for k, d in enumerate(sorted((d for d in pkg["drift_table"] if d.get("drift_amplified") is not None), key=lambda d: d.get("story", 0))):
        pass
    by = {}
    for d in pkg["drift_table"]:
        if d.get("drift_amplified") is not None:
            by[d.get("story")] = max(by.get(d.get("story"), 0.0), float(d["drift_amplified"]))
    for st in sorted(by):
        z += H[st - 1] * 12.0
        dm += by[st] * H[st - 1] * 12.0
        fa = dA * z / hA
        fl = 0.025 * z
        rows_.append(dict(level="floor at +10 ft" if st == 1 else "lid at +20 ft", height_in=z, mezzanine_displacement_in=round(dm, 2),
                          frame_displacement_across_shop_in=round(fa, 2), separation_across_shop_in=round(math.hypot(dm, fa), 2), gap_provided_across_shop_in=GAP_SIDE,
                          frame_displacement_along_shop_in=round(fl, 2), separation_along_shop_in=round(math.hypot(dm, fl), 2), gap_provided_along_shop_in=GAP_END))
    return dict(decision="Seismic joint. The mezzanine (strap-braced walls, R = 4) and the shop (special bolted moment frames, R = 3.5, across the shop; strap bracing along it) are separate structures. Nothing of the mezzanine is fastened to a frame "
                         "column, girt or beam, so the two systems never act together on one axis and the least-R rule of ASCE 7-22 12.2.3.3 is not invoked. The brief's alternative, tying the mezzanine roof line to the frame columns, would load "
                         "a drift-governed moment frame (2 percent drift) with a stiff braced box and is not adopted.",
                basis="ASCE 7-22 12.12.2 (Eq. 12.12-2): separation = square root of the sum of the squares of the maximum inelastic displacements of the two structures at the level considered. Mezzanine: sum of its Cd-amplified storey drifts. "
                      "Shop, across the span: the frame design story drift of part A (%.2f in. at the 24 ft eave), taken as linear with height. Shop, along its length: the strap-braced side walls are taken at the allowable 0.025 h." % dA,
                rows=rows_,
                consequences=["The mezzanine has strap-braced walls on all four sides, including the side facing the shop floor, which the brief left to the frame line.",
                              "Plan size is 46 ft 6 in. by 48 ft (wall centrelines) instead of 50 ft by 50 ft, so that the walls clear the 12 in. columns and the end-wall framing by the gaps listed.",
                              "Stairs, landings, services and any closure flashing that cross the gap are detailed to move by the separation listed; the guard at the shop side is on the mezzanine only.",
                              "The moment frames of part A carry no mezzanine weight; their seismic weight, drift and capacity design are unaffected by the mezzanine."])


def accidental_torsion(pkg, wd):
    Vs = {}
    for w in pkg["wall_lines"]:
        Vs.setdefault((w.get("direction") or w["id"].split("-")[1], w["story"]), []).append(w)
    out = []
    for (d, st), ws in sorted(Vs.items()):
        Vst = sum(float(w["V_kip"]) for w in ws)
        a_, b_ = (BY, BX) if d == "X" else (BX, BY)          # a_: plan dimension perpendicular to the force
        share = 0.5 + 0.05 * a_ ** 2 / (a_ ** 2 + b_ ** 2)
        for w in ws:
            used = float(w["V_kip"]) / Vst
            out.append(dict(line=w["id"], story=st, share_used=round(used, 3), share_stiff_floor_with_accidental_torsion=round(share, 3), wall_DC_as_designed=w["DC"], wall_DC_at_the_larger_share=round(float(w["DC"]) * max(1.0, share / used), 3)))
    return dict(basis="ASCE 7-22 12.8.4.2: for a diaphragm that is not flexible the storey shear is applied 5 percent of the plan dimension off the centre of mass. With four equal perimeter lines the torsion 0.05 a V is resisted by all four lines, "
                      "and the line parallel to the force takes V (0.5 + 0.05 a^2 / (a^2 + b^2)), a = plan dimension perpendicular to the force, b = the other dimension. The shares below are fractions of the storey shear carried by the two lines of the direction.",
                rows=out, conclusion="every braced line remains within its strength at the larger of the two shares; the straps, and with them the capacity-designed chords, tie-downs and anchorage, are unchanged")


SPEC = dict(
    name="CFS_Ex18_B", arch="CFS_Ex18 two-level mezzanine inside the fabrication shop (part B), flat-strap X-braced walls, separated from the shop frames by a seismic joint", occupancy="Offices at grade with a storage floor above (B / S-1), inside the fabrication shop",
    H=H, plan=(BX, BY), area_sf=BX * BY, perimeter_ft=2.0 * (BX + BY), kind="strap", system="strap_braced", risk="II", site="D",
    cfg_extra=dict(storage=True),
    loads=dict(D_floor=D_FLOOR, D_roof=D_LID, clad=0.0, L_floor=L_STORE, partition_psf=0.0, Lr=L_LID, snow=0.0, snow_pg=0.0),
    seis=dict(SDS=0.75, SD1=0.30, S1=0.20), rho=1.0, drift_tolerant=True,
    diaphragm=dict(mode="flexible", material="wood structural panel on cold-formed steel joists with a non-structural gypsum topping", topping_in=1.0, sel=dict(bldg.WSP_ROOF)),
    lines=lines, gravity_lines=gravity, zones=zones, step0=1, chord_nmax=6, chord_section="600S250-97",
    joist_span_ft=11.625, joist_spacing_in=16.0, stud_trib_ft=11.625, chord_trib_sf=4.0 * 6.0,
    floor_shear=dict(screw="No. 12", rows=2, spacing_in=4.0),
    joists=[dict(id="joist-store", label="storage floor joist", section="1000S200-68", Fy=50.0, span_ft=11.625, spacing_in=16.0, D=D_FLOOR, L=L_STORE, level="floor"),
            dict(id="joist-lid", label="lid joist", section="800S162-43", Fy=50.0, span_ft=11.625, spacing_in=24.0, D=D_LID, L=L_LID, level="roof")],
    headers=[],
    stud_groups=[dict(id="stud-bearing", label="interior bearing wall", where="three interior bearing walls at 11 ft 7-1/2 in., carrying the storage floor and the lid from both sides", exterior=False, Fy=50.0, wall_psf=8.0, trib_ft=11.625, roof_trib_ft=11.625,
                      spacing_in=16.0, candidates=["600S162-54", "600S162-68", "600S200-68", "600S200-97", "600S250-97"], story_groups=[(1, 1), (2, 2)]),
                 dict(id="stud-side", label="east and west walls", where="east and west walls, carrying half a joist span of the storage floor and of the lid", exterior=False, Fy=50.0, wall_psf=8.0, trib_ft=5.8125, roof_trib_ft=5.8125,
                      spacing_in=16.0, candidates=["600S162-43", "600S162-54", "600S162-68", "600S200-68"], story_groups=[(1, 1), (2, 2)]),
                 dict(id="stud-end", label="north and south walls", where="north and south walls, parallel to the joists", exterior=False, Fy=50.0, wall_psf=8.0, trib_ft=1.33, roof_trib_ft=1.33,
                      spacing_in=16.0, candidates=["600S162-43", "600S162-54"], story_groups=[(1, 1), (2, 2)])],
    materials=rows, physical_materials=pm,
    layout=dict(floor_zone_in=10.0 + 0.46875 + 0.0713 / 2.0, wall_depth_in=6.0, deck_thickness_in=0.46875, top_level_name="Lid",
                coverage=dict(
                    primary_members="All four strap-braced wall lines at both storeys: tracks, studs, chord packs, the X-bracing straps of every braced bay on both faces, and tie-down rods at both ends of every bay.",
                    secondary_members="The three interior bearing walls, every storage floor joist and lid joist, and the floor and lid sheathing as diaphragm panels; joist blocking, the stair and the guard are not located.",
                    openings="The project brief does not locate door or window openings in the mezzanine walls and none are modelled.",
                    connections="Stud-to-track screws at every stud end, strap-to-gusset and gusset-to-framing screws at every strap end, bottom-track anchors and wall-to-floor shear screws at every braced bay, chord-ply interconnection, tie-down couplers and terminations and joist bearing screws are located solids in versioned assemblies; anchorage into the shop slab and footings is delegated.")),
    rho_justification="ASCE 7-22 12.3.4.2 condition (b): the plan is regular and every side of the perimeter has two 12 ft strap-braced bays at each storey; for light-frame walls the number of bays is 2 L / hsx = 2 x 12 / 10 = 2.4 per panel, 4.8 on each side, more than the 2 required, so rho = 1.0.",
    records=dict(seismic_joint_at_shop_frames=seismic_joint, accidental_torsion_stiff_floor=accidental_torsion,
                 posted_load=dict(statement="STORAGE FLOOR: MAXIMUM LOAD 125 POUNDS PER SQUARE FOOT, UNIFORMLY DISTRIBUTED.",
                                  basis="The 125 psf storage live load is not reduced (ASCE 7-22 4.7.3) and 25 percent of it is in the seismic weight (12.7.2 item 1). The office live load of the brief (50 psf with 15 psf partitions) is enveloped by the storage load, so any part "
                                        "of the floor may be used for either purpose. Offices at grade stand on the shop slab.")),
    design_notes=[
        "Seismic design category: SDS = 0.75 g and SD1 = 0.30 g in Risk Category II give Seismic Design Category D (ASCE 7-22 Tables 11.6-1 and 11.6-2), not C as the brief states. S1 is not given and is taken as 0.20 g.",
        "Separate structure. The mezzanine stands on its own strap-braced walls and is separated from the shop frames by a seismic joint on all sides; the joint record gives the displacements and gaps. It is designed as a two-storey building under ASCE 7-22 Chapter 12 with the cold-formed steel strap-braced wall system of AISI S400 E3 (R = 4, Omega0 = 2, Cd = 3.5).",
        "Levels and loads. Offices at grade on the shop slab; the framed floor at +10 ft is designed throughout for 125 psf storage, not reduced, which envelopes the 50 psf office load with partitions; the lid at +20 ft is a ceiling and dust cover with 12 psf dead load and a 20 psf maintenance live load. The mezzanine is inside the enclosed shop: no wind and no snow act on it.",
        "Diaphragms. The topped floor is stiff and the shop roof is a flexible bare deck; they belong to different structures. Within the mezzanine the four perimeter lines are symmetric about both axes, so the rigid and the tributary-width distributions give each line half of the storey shear; the accidental-torsion record repeats the distribution for the stiff floor with the 5 percent eccentricity of ASCE 7-22 12.8.4.2 and compares it with the line shears used.",
        "Bearing walls. Joists span 11 ft 7-1/2 in. between three interior bearing walls and the east and west walls. The ground-storey studs carry the storage floor and the lid; the full 125 psf is used with no live-load reduction.",
        "Capacity design. Chord studs, tie-down rods, anchorage and collectors of every braced bay are designed for the expected yield strength of the straps (Ry Fy Ag, AISI S400 E3).",
        "Foundations. The mezzanine walls stand on thickened strips of the shop slab or on footings designed by others for the reactions tabulated; tie-down anchorage is to ACI 318-19 Chapter 17 by the foundation engineer.",
    ],
)
cfg = bldg.cfg(SPEC)
