Steltic physical-data export, stage 2

61 evidence packages are in packages/HR and packages/CFS.
All retain needs_input status; they are not drawing-ready designs.
Read docs/stage2/README.md and contracts/BIM_EXPORT.md.
Original calculation data is preserved in each package. No RAG extracts are included.
