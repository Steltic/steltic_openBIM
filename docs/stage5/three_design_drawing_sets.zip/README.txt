STELTIC OPENBIM — DIMENSIONED DESIGN DRAWING PILOTS

Open index.html, or open each building's drawings.pdf directly.

hr22: six-storey HR hospital — 19 A1 sheets, 6 adopted answers.
cfs16: CFS portal-frame warehouse — 17 A1 sheets, 5 adopted answers.
cfs8: CFS student housing — 40 A1 sheets, 7 adopted answers.

The user authorized sensible invented answers for these fictional buildings.
S means source design input. A means assumed test input. The general notes and
G002 answer register explain the changes. No new structural analysis or capacity
verification was performed. These are design drawing test sets, not construction
or fabrication issues. IFC export is outside this release.

Each building folder contains:
  drawings.pdf — dimensioned A1 drawing set
  adopted_answers.json — all adopted answers and their provenance
  information_requests.json — Hub-compatible information request register
  member_index.json — every member instance and its type mark/reference
  design_model.json — source-derived and supplemented drawing geometry
  source_records.json — original engineering records
  drawing_manifest.json — sheet, scale, dimension and callout audit
  state.json — drawing revision and decision state
  preview.png — selected rendered sheet

Root files include verification.json and a Hub query screenshot. The installable
0.4.0 wheel is supplied alongside this archive. Install with the [hub] extra in an
environment that has access to its dependencies.

Original HR/CFS outputs are unchanged. All 812 source files / 61 test buildings
were audited. The three scenarios are bound to the exact original package hashes;
fictional answers are never automatically applied to ordinary jobs.
